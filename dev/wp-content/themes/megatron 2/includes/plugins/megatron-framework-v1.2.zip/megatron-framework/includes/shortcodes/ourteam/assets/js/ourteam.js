/**
 * Created by trungpq on 15/09/2015.
 */
(function ($) {
    "use strict";
    var G5PlusOurteam = {
        init: function() {
            if ($('.ourteam').length) {
                $('.ourteam-avatar-inner').each(function () {
                    $('div',this).attr('style','width:'+ $('img',this).width()+'px');
                    $('div',this).attr('style','height:'+ $('img',this).height()+'px');
                })
            }
        }
    };
    $(document).ready(G5PlusOurteam.init);
    $(window).resize(G5PlusOurteam.init);
})(jQuery);